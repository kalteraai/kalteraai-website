import React, { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { Canvas } from "@react-three/fiber";
import { Float, Environment, RoundedBox, ContactShadows } from "@react-three/drei";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Lenis from "lenis";
import {
  ArrowRight,
  Check,
  Clock3,
  Globe2,
  Menu,
  MessageCircle,
  Phone,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const BRAND = {
  name: "KALTERA AI",
  tagline: "Software • Automation • Business Solutions",
  subtagline: "Helping businesses scale with technology.",
  founder: "Supti Biswas",
  location: "Kolkata, West Bengal, India",
  email: "hello@kalteraai.com",
  phone: "+91 9836565863",
  whatsapp: "https://wa.me/919836565863",
  calendly: "https://calendly.com/hello-kalteraai/30min",
  linkedin: "https://linkedin.com/company/kaltera-ai",
  twitter: "https://x.com/kalteraai",
  logoSrc: "/kaltera-logo-dark.png", // use the original uploaded KALTERA logo exactly as provided
};

const services = [
  {
    title: "Software Solutions",
    copy: "Custom business software that replaces scattered tools with one calm, reliable operating layer.",
    tags: ["Web apps", "Internal systems", "Portals"],
  },
  {
    title: "Automation Systems",
    copy: "Reduce manual work across sales, operations, communication, and reporting with practical automation.",
    tags: ["Workflows", "Alerts", "Integration"],
  },
  {
    title: "Workflow Optimization",
    copy: "Clarify process bottlenecks, remove duplication, and make day-to-day execution more consistently.",
    tags: ["Process review", "Efficiency", "Operations"],
  },
  {
    title: "Cybersecurity Services",
    copy: "Security-minded implementation that protects business data, access, and customer trust.",
    tags: ["Hardening", "Access control", "Risk reduction"],
  },
  {
    title: "Business Consulting",
    copy: "Consultation-first guidance that connects business goals with practical digital execution.",
    tags: ["Planning", "Advisory", "Coordination"],
  },
  {
    title: "Custom Digital Systems",
    copy: "Tailored systems for lead handling, CRM, dashboards, reporting, and operational visibility.",
    tags: ["CRM", "Dashboards", "Systems"],
  },
];

const industries = [
  ["Startups", "Move fast without breaking operations."],
  ["Clinics", "Manage appointments, follow-ups, and patient communication cleanly."],
  ["Agencies", "Track projects, leads, and client delivery without tool chaos."],
  ["Local Businesses", "Digitize everyday admin work and improve response speed."],
  ["SMBs", "Build lean systems that support growth without adding overhead."],
  ["Real Estate", "Coordinate inquiries, site visits, and lead nurturing in one flow."],
  ["E-Commerce", "Improve order visibility, notifications, and reporting discipline."],
  ["Service Businesses", "Keep inquiry handling, scheduling, and payments organized."],
];

const whyChoose = [
  ["Tailored Solutions", "Built around how your business actually operates, not generic templates."],
  ["Founder-Led Coordination", "Direct communication, faster decisions, and more accountable execution."],
  ["Practical Systems", "Focused on outcomes that teams can use immediately."],
  ["Secure Infrastructure", "Security-aware setup for trust, access, and continuity."],
  ["Scalable Operations", "Designed to support growth without creating complexity."],
  ["Business-Focused Implementation", "Technology mapped to process, communication, and conversion."],
];

const process = [
  ["Discovery", "Understand goals, current systems, pain points, and desired outcomes."],
  ["Audit", "Review workflows, tools, communication gaps, and manual effort."],
  ["Strategy", "Create a clear roadmap with practical priorities and implementation scope."],
  ["Build", "Develop the required software, automation, or business system."],
  ["Testing", "Validate reliability, edge cases, usability, and secure behavior."],
  ["Launch", "Deploy with careful handover, documentation, and support."],
  ["Optimization", "Refine the system based on real usage and operational feedback."],
];

const caseStudies = [
  ["Workflow Automation", "Automated task routing, approval handling, and recurring operations."],
  ["WhatsApp Automation", "Faster lead responses, reminders, and customer communication flows."],
  ["CRM Systems", "Structured lead stages, follow-up logic, and pipeline visibility."],
  ["Reporting Dashboards", "Decision-ready views for sales, operations, and performance."],
  ["Cybersecurity Systems", "Access control, process hardening, and safer digital operations."],
];

function App() {
  const [modalOpen, setModalOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [navVisible, setNavVisible] = useState(true);
  const lastScroll = useRef(0);

  useSeo();
  useSmoothScroll();
  useScrollDirection(setNavVisible, lastScroll);
  useRevealAnimations();

  return (
    <div className="app-shell">
      <GlobalStyles />

      <FixedNavigation
        visible={navVisible}
        mobileNavOpen={mobileNavOpen}
        setMobileNavOpen={setMobileNavOpen}
        openModal={() => setModalOpen(true)}
      />

      <main>
        <HeroSection openModal={() => setModalOpen(true)} />
        <ServicesSection />
        <IndustriesSection />
        <WhyChooseSection />
        <ProcessSection />
        <CaseStudiesSection />
        <FounderSection />
        <ConsultationCTA openModal={() => setModalOpen(true)} />
      </main>

      <Footer openModal={() => setModalOpen(true)} />

      <ConsultationModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
}

function FixedNavigation({ visible, mobileNavOpen, setMobileNavOpen, openModal }) {
  return (
    <motion.header
      initial={false}
      animate={{ y: visible ? 0 : -100, opacity: visible ? 1 : 0.9 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="nav-wrap"
    >
      <nav className="nav-bar" aria-label="Primary navigation">
        <a className="logo-badge" href="#top" aria-label="KALTERA AI home">
          <img src={BRAND.logoSrc} alt="KALTERA AI logo" className="logo-img" />
        </a>

        <div className="nav-links desktop-only">
          <a href="#services">Services</a>
          <a href="#process">Process</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </div>

        <div className="nav-actions">
          <a className="nav-phone desktop-only" href={`tel:${BRAND.phone.replace(/\s/g, "")}`}>
            <Phone size={16} /> {BRAND.phone}
          </a>
          <button className="btn btn-primary" onClick={openModal}>
            Book Consultation
          </button>
          <button
            className="mobile-menu-btn mobile-only"
            aria-expanded={mobileNavOpen}
            aria-controls="mobile-nav-panel"
            onClick={() => setMobileNavOpen((v) => !v)}
          >
            {mobileNavOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {mobileNavOpen && (
          <motion.div
            id="mobile-nav-panel"
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            transition={{ duration: 0.25 }}
            className="mobile-panel"
          >
            <a href="#services" onClick={() => setMobileNavOpen(false)}>Services</a>
            <a href="#process" onClick={() => setMobileNavOpen(false)}>Process</a>
            <a href="#about" onClick={() => setMobileNavOpen(false)}>About</a>
            <a href="#contact" onClick={() => setMobileNavOpen(false)}>Contact</a>
            <button className="btn btn-primary full-width" onClick={openModal}>Book Consultation</button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}

function HeroSection({ openModal }) {
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rotateX = useSpring(useTransform(my, [-0.5, 0.5], [10, -10]), { stiffness: 120, damping: 18 });
  const rotateY = useSpring(useTransform(mx, [-0.5, 0.5], [-12, 12]), { stiffness: 120, damping: 18 });

  return (
    <section id="top" className="hero section-grid">
      <div className="hero-copy reveal">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="eyebrow"
        >
          <Sparkles size={14} /> MSME Registered • Kolkata, West Bengal, India
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.05 }}
          className="hero-title"
        >
          Automate. <span>Secure.</span> Scale.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.12 }}
          className="hero-copy-text"
        >
          Technology systems built for modern businesses. KALTERA AI helps teams improve operations through software systems, workflow automation, cybersecurity, operational efficiency, and scalable digital infrastructure.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.18 }}
          className="hero-actions"
        >
          <button className="btn btn-primary" onClick={openModal}>Book Free Consultation</button>
          <a className="btn btn-secondary" href="#services">Explore Services <ArrowRight size={16} /></a>
        </motion.div>

        <div className="hero-proof">
          <div><strong>Founder-led</strong><span>Direct communication</span></div>
          <div><strong>Consultation-first</strong><span>Practical planning</span></div>
          <div><strong>Business-focused</strong><span>Clear execution</span></div>
        </div>
      </div>

      <motion.div
        className="hero-visual reveal"
        onMouseMove={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          const x = (e.clientX - r.left) / r.width - 0.5;
          const y = (e.clientY - r.top) / r.height - 0.5;
          mx.set(x);
          my.set(y);
        }}
        onMouseLeave={() => {
          mx.set(0);
          my.set(0);
        }}
        style={{ rotateX, rotateY }}
      >
        <HeroScene />
        <div className="visual-overlay">
          <div className="glass-card card-a">
            <span>Operations</span>
            <strong>Structured workflows</strong>
          </div>
          <div className="glass-card card-b">
            <span>Automation</span>
            <strong>Faster responses</strong>
          </div>
          <div className="glass-card card-c">
            <span>Security</span>
            <strong>Protected systems</strong>
          </div>
        </div>
      </motion.div>
    </section>
  );
}

function HeroScene() {
  return (
    <Canvas camera={{ position: [0, 0, 7], fov: 42 }} dpr={[1, 1.75]}>
      <color attach="background" args={["#fcfaf6"]} />
      <ambientLight intensity={1.4} />
      <directionalLight position={[3, 4, 5]} intensity={2.1} color="#d6b26f" />
      <directionalLight position={[-4, -2, 2]} intensity={1.2} color="#1f2d6b" />
      <Environment preset="city" />

      <group position={[0, 0.1, 0]}>
        <Float speed={1.2} rotationIntensity={0.25} floatIntensity={0.8}>
          <RoundedBox args={[2.9, 1.7, 0.18]} radius={0.09} smoothness={10} position={[0, 0.2, 0]}>
            <meshPhysicalMaterial
              color="#ffffff"
              roughness={0.15}
              transmission={0.8}
              thickness={1.2}
              clearcoat={1}
              clearcoatRoughness={0.2}
              metalness={0.05}
              ior={1.4}
            />
          </RoundedBox>

          <RoundedBox args={[2.15, 0.22, 0.12]} radius={0.06} smoothness={8} position={[0, -0.55, 0.04]}>
            <meshPhysicalMaterial color="#1f2d6b" roughness={0.25} transmission={0.18} opacity={0.94} transparent />
          </RoundedBox>

          <mesh position={[-0.95, 0.7, 0.18]} rotation={[0, 0.4, 0.1]}>
            <icosahedronGeometry args={[0.32, 0]} />
            <meshPhysicalMaterial color="#d6b26f" roughness={0.18} metalness={0.6} clearcoat={1} />
          </mesh>

          <mesh position={[1.0, 0.3, 0.22]} rotation={[0.2, 0.1, 0.3]}>
            <torusKnotGeometry args={[0.18, 0.06, 120, 16]} />
            <meshPhysicalMaterial color="#1f2d6b" roughness={0.22} metalness={0.45} />
          </mesh>
        </Float>
      </group>

      <ContactShadows opacity={0.35} scale={8} blur={2.8} far={4.5} position={[0, -2.0, 0]} />
    </Canvas>
  );
}

function ServicesSection() {
  return (
    <section id="services" className="section block-light">
      <SectionHeading
        eyebrow="Services"
        title="Technology that works for your business."
        copy="KALTERA AI creates practical systems that simplify operations, improve communication, and support sustainable growth."
      />
      <div className="card-grid reveal-grid">
        {services.map((item) => (
          <motion.article
            key={item.title}
            whileHover={{ y: -6, rotateX: 2, rotateY: -2 }}
            transition={{ type: "spring", stiffness: 220, damping: 18 }}
            className="premium-card"
          >
            <div className="card-topline" />
            <h3>{item.title}</h3>
            <p>{item.copy}</p>
            <div className="tag-row">
              {item.tags.map((tag) => <span key={tag}>{tag}</span>)}
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}

function IndustriesSection() {
  return (
    <section className="section block-ivory">
      <SectionHeading
        eyebrow="Industries"
        title="Built for businesses that need cleaner operations."
        copy="The focus is on real operational friction: manual work, fragmented workflows, communication gaps, and scaling pressure."
      />
      <div className="industry-grid reveal-grid">
        {industries.map(([name, desc]) => (
          <motion.div key={name} whileHover={{ y: -4 }} className="industry-card">
            <div className="industry-icon"><Globe2 size={16} /></div>
            <h3>{name}</h3>
            <p>{desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

function WhyChooseSection() {
  return (
    <section id="about" className="section block-light">
      <SectionHeading
        eyebrow="Why KALTERA AI"
        title="A premium partner for practical digital execution."
        copy="Trust signals are built into the experience: direct communication, a consultation-first process, and systems that support the business rather than overwhelm it."
      />
      <div className="why-wrap reveal-grid">
        <div className="trust-panel">
          <div className="trust-pill"><Check size={14} /> MSME Registered</div>
          <div className="trust-pill"><Check size={14} /> Founder-led coordination</div>
          <div className="trust-pill"><Check size={14} /> Direct communication</div>
          <div className="trust-pill"><Check size={14} /> Practical implementation</div>
        </div>
        <div className="feature-grid">
          {whyChoose.map(([title, desc]) => (
            <article className="feature-card" key={title}>
              <h3>{title}</h3>
              <p>{desc}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProcessSection() {
  return (
    <section id="process" className="section block-ivory">
      <SectionHeading
        eyebrow="Process"
        title="A calm, methodical path from insight to launch."
        copy="The timeline is designed to feel organized and credible, with each step revealing only what comes next."
      />
      <div className="timeline reveal-grid">
        {process.map(([step, desc], idx) => (
          <motion.div key={step} className="timeline-item process-step" whileHover={{ y: -3 }}>
            <div className="timeline-index">{String(idx + 1).padStart(2, "0")}</div>
            <div>
              <h3>{step}</h3>
              <p>{desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

function CaseStudiesSection() {
  return (
    <section className="section block-light">
      <SectionHeading
        eyebrow="Demo / Case Studies"
        title="Premium showcase cards for real system outcomes."
        copy="These examples communicate what the company builds: automation, CRM structure, dashboards, and secure operational systems."
      />
      <div className="case-grid reveal-grid">
        {caseStudies.map(([title, desc], idx) => (
          <motion.article key={title} className={`case-card case-${idx + 1}`} whileHover={{ scale: 1.01 }}>
            <div className="case-badge">Case {idx + 1}</div>
            <div className="case-visual">
              <div className="case-orb" />
              <div className="case-line" />
            </div>
            <h3>{title}</h3>
            <p>{desc}</p>
          </motion.article>
        ))}
      </div>
    </section>
  );
}

function FounderSection() {
  return (
    <section className="section block-ivory founder-section">
      <SectionHeading
        eyebrow="Founder"
        title="Human, credible, and business-led."
        copy="The brand story should feel grounded: KALTERA AI helps businesses adopt practical digital systems and workflows that simplify operations and support growth."
      />
      <div className="founder-panel reveal-grid">
        <div className="founder-portrait">
          <div className="portrait-ring" />
          <div className="portrait-initials">SB</div>
        </div>
        <div className="founder-copy">
          <h3>{BRAND.founder}</h3>
          <p>
            KALTERA AI focuses on practical implementation, clear coordination, and strong business communication. The goal is not to look futuristic; the goal is to make digital operations feel reliable, elegant, and easier to manage.
          </p>
          <div className="founder-notes">
            <span><Clock3 size={14} /> Consultation-first</span>
            <span><ShieldCheck size={14} /> Security-aware</span>
            <span><MessageCircle size={14} /> Direct support</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function ConsultationCTA({ openModal }) {
  return (
    <section id="contact" className="cta-section">
      <div className="cta-inner reveal">
        <div className="cta-eyebrow">Consultation</div>
        <h2>Let’s build smarter systems for your business.</h2>
        <p>
          A premium, focused conversation to understand your current setup and identify the right software, automation, or cybersecurity path.
        </p>
        <div className="cta-actions">
          <button className="btn btn-primary" onClick={openModal}>Book Free Consultation</button>
          <a className="btn btn-secondary dark" href={BRAND.whatsapp} target="_blank" rel="noreferrer">
            Contact on WhatsApp <MessageCircle size={16} />
          </a>
        </div>
      </div>
    </section>
  );
}

function Footer({ openModal }) {
  return (
    <footer className="footer">
      <div className="footer-top">
        <div>
          <a href="#top" className="footer-logo-wrap">
            <img src={BRAND.logoSrc} alt="KALTERA AI" className="footer-logo" />
          </a>
          <p>{BRAND.tagline}</p>
          <p>{BRAND.subtagline}</p>
        </div>

        <div>
          <h3>Quick Links</h3>
          <a href="#services">Services</a>
          <a href="#process">Process</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </div>

        <div>
          <h3>Services</h3>
          <span>Software Solutions</span>
          <span>Automation Systems</span>
          <span>Cybersecurity Services</span>
          <span>Business Consulting</span>
        </div>

        <div>
          <h3>Contact</h3>
          <a href={`mailto:${BRAND.email}`}>{BRAND.email}</a>
          <a href={`tel:${BRAND.phone.replace(/\s/g, "")}`}>{BRAND.phone}</a>
          <a href={BRAND.calendly} target="_blank" rel="noreferrer">Calendly</a>
          <a href={BRAND.linkedin} target="_blank" rel="noreferrer">LinkedIn</a>
          <a href={BRAND.twitter} target="_blank" rel="noreferrer">X / Twitter</a>
          <button className="footer-btn" onClick={openModal}>Book Consultation</button>
        </div>
      </div>

      <div className="footer-bottom">
        <span>{BRAND.location}</span>
        <span>MSME Registered</span>
        <span>© {new Date().getFullYear()} {BRAND.name}. All rights reserved.</span>
      </div>
    </footer>
  );
}

function ConsultationModal({ open, onClose }) {
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!open) setSubmitted(false);
  }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div
            className="modal-shell"
            initial={{ opacity: 0, y: 30, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 18, scale: 0.98 }}
            transition={{ duration: 0.25 }}
            role="dialog"
            aria-modal="true"
            aria-labelledby="consultation-title"
          >
            <button className="modal-close" onClick={onClose} aria-label="Close consultation form">
              <X size={18} />
            </button>

            <div className="modal-header">
              <div className="modal-eyebrow">Consultation</div>
              <h2 id="consultation-title">Book a conversation with KALTERA AI</h2>
              <p>Share a few details so the conversation can focus on the right business systems, automation, or security needs.</p>
            </div>

            {submitted ? (
              <div className="submission-state">
                <ShieldCheck size={28} />
                <h3>Request captured</h3>
                <p>Your inquiry is ready to be connected to the team flow.</p>
                <button className="btn btn-primary" onClick={onClose}>Close</button>
              </div>
            ) : (
              <form
                className="consultation-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  setSubmitted(true);
                }}
              >
                <div className="form-grid">
                  <Field label="Name" placeholder="Your name" />
                  <Field label="Email" type="email" placeholder="you@company.com" />
                  <Field label="Company" placeholder="Company name" />
                  <SelectField
                    label="Service interest"
                    options={[
                      "Software Development",
                      "Automation",
                      "Cybersecurity",
                      "Consulting",
                      "Custom Systems",
                    ]}
                  />
                </div>
                <label className="field field-full">
                  <span>Message</span>
                  <textarea rows={5} placeholder="Describe your challenge, current workflow, or what you want to improve." />
                </label>

                <div className="form-footer">
                  <div className="form-note">
                    <Check size={14} /> Direct, practical consultation
                  </div>
                  <button className="btn btn-primary" type="submit">Submit Request</button>
                </div>
              </form>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Field({ label, type = "text", placeholder }) {
  return (
    <label className="field">
      <span>{label}</span>
      <input type={type} placeholder={placeholder} />
    </label>
  );
}

function SelectField({ label, options }) {
  return (
    <label className="field">
      <span>{label}</span>
      <select defaultValue="">
        <option value="" disabled>Choose a service</option>
        {options.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
      </select>
    </label>
  );
}

function SectionHeading({ eyebrow, title, copy }) {
  return (
    <div className="section-heading reveal">
      <div className="eyebrow small">{eyebrow}</div>
      <h2>{title}</h2>
      <p>{copy}</p>
    </div>
  );
}

function useSeo() {
  useEffect(() => {
    const upsertMeta = (selector, attrs) => {
      let el = document.head.querySelector(selector);
      if (!el) {
        el = document.createElement("meta");
        document.head.appendChild(el);
      }
      Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
    };

    const upsertLink = (selector, attrs) => {
      let el = document.head.querySelector(selector);
      if (!el) {
        el = document.createElement("link");
        document.head.appendChild(el);
      }
      Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
    };

    document.title = "KALTERA AI | Software, Automation & Business Solutions";
    upsertMeta('meta[name="description"]', {
      name: "description",
      content:
        "KALTERA AI is a premium software development, workflow automation, and cybersecurity company in Kolkata helping businesses scale with practical digital systems.",
    });
    upsertMeta('meta[name="robots"]', { name: "robots", content: "index, follow" });
    upsertMeta('meta[name="theme-color"]', { name: "theme-color", content: "#fcfaf6" });
    upsertMeta('meta[property="og:title"]', { property: "og:title", content: document.title });
    upsertMeta('meta[property="og:description"]', {
      property: "og:description",
      content:
        "Premium business technology systems for automation, software, cybersecurity, and operational efficiency.",
    });
    upsertMeta('meta[property="og:type"]', { property: "og:type", content: "website" });
    upsertMeta('meta[property="og:locale"]', { property: "og:locale", content: "en_IN" });
    upsertMeta('meta[name="twitter:card"]', { name: "twitter:card", content: "summary_large_image" });
    upsertMeta('meta[name="twitter:title"]', { name: "twitter:title", content: document.title });
    upsertMeta('meta[name="twitter:description"]', {
      name: "twitter:description",
      content:
        "KALTERA AI builds elegant software, automation, and security systems for modern businesses.",
    });
    upsertLink('link[rel="canonical"]', { rel: "canonical", href: "https://kalteraai.com" });

    const schema = {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      name: BRAND.name,
      description:
        "Software development, workflow automation, cybersecurity, and business consulting company.",
      url: "https://kalteraai.com",
      email: BRAND.email,
      telephone: BRAND.phone,
      address: {
        "@type": "PostalAddress",
        addressLocality: "Kolkata",
        addressRegion: "West Bengal",
        addressCountry: "IN",
      },
      founder: BRAND.founder,
      areaServed: ["Kolkata", "West Bengal", "India"],
      sameAs: [BRAND.linkedin, BRAND.twitter],
    };

    let ld = document.getElementById("kaltera-jsonld");
    if (!ld) {
      ld = document.createElement("script");
      ld.type = "application/ld+json";
      ld.id = "kaltera-jsonld";
      document.head.appendChild(ld);
    }
    ld.textContent = JSON.stringify(schema);
  }, []);
}

function useSmoothScroll() {
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.1,
      smoothWheel: true,
      lerp: 0.1,
    });

    let rafId = 0;
    const raf = (time) => {
      lenis.raf(time);
      rafId = requestAnimationFrame(raf);
    };
    rafId = requestAnimationFrame(raf);

    return () => {
      cancelAnimationFrame(rafId);
      lenis.destroy();
    };
  }, []);
}

function useScrollDirection(setNavVisible, lastScroll) {
  useEffect(() => {
    const onScroll = () => {
      const current = window.scrollY;
      const delta = current - lastScroll.current;
      if (current < 40) setNavVisible(true);
      else if (delta > 8) setNavVisible(false);
      else if (delta < -8) setNavVisible(true);
      lastScroll.current = current;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [setNavVisible, lastScroll]);
}

function useRevealAnimations() {
  useEffect(() => {
    const targets = gsap.utils.toArray(".reveal, .reveal-grid");
    targets.forEach((el) => {
      gsap.fromTo(
        el,
        { opacity: 0, y: 26 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          ease: "power2.out",
          scrollTrigger: { trigger: el, start: "top 82%" },
        }
      );
    });

    ScrollTrigger.batch(".process-step", {
      onEnter: (batch) =>
        gsap.to(batch, {
          opacity: 1,
          y: 0,
          stagger: 0.08,
          duration: 0.65,
          ease: "power2.out",
        }),
      onLeaveBack: (batch) =>
        gsap.to(batch, {
          opacity: 0.58,
          y: 16,
          stagger: 0.05,
          duration: 0.4,
          ease: "power2.out",
        }),
      start: "top 82%",
    });

    return () => ScrollTrigger.getAll().forEach((t) => t.kill());
  }, []);
}

function GlobalStyles() {
  return (
    <style>{`
      :root {
        --gold: #d6b26f;
        --blue: #1f2d6b;
        --ivory: #f7f3eb;
        --warm: #fcfaf6;
        --charcoal: #1b1b1b;
        --muted: #5e5e5e;
        --border: rgba(0,0,0,0.08);
        --card: rgba(255,255,255,0.72);
        --shadow: 0 20px 60px rgba(31,45,107,0.08);
      }

      * { box-sizing: border-box; }
      html { scroll-behavior: auto; }
      body {
        margin: 0;
        background: linear-gradient(180deg, #fcfaf6 0%, #f7f3eb 100%);
        color: var(--charcoal);
        font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        -webkit-font-smoothing: antialiased;
        text-rendering: optimizeLegibility;
      }
      a { color: inherit; text-decoration: none; }
      button, input, textarea, select { font: inherit; }
      img { display: block; max-width: 100%; }

      .app-shell { min-height: 100vh; overflow-x: hidden; }
      .section-grid, .section, .cta-section, .footer {
        width: min(1200px, calc(100vw - 32px));
        margin: 0 auto;
      }

      .nav-wrap {
        position: fixed;
        inset: 16px 0 auto 0;
        z-index: 60;
        pointer-events: none;
      }
      .nav-bar {
        pointer-events: auto;
        width: min(1200px, calc(100vw - 24px));
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        padding: 10px 14px;
        border-radius: 18px;
        background: rgba(255,248,235,0.95);
        border: 1px solid rgba(214,178,111,0.18);
        box-shadow: 0 16px 40px rgba(31,45,107,0.09);
        backdrop-filter: blur(16px);
      }
      .logo-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 8px 18px;
        border-radius: 14px;
        background: rgba(255,248,235,0.95);
        border: 1px solid rgba(214,178,111,0.18);
        box-shadow: 0 10px 24px rgba(31,45,107,0.06);
      }
      .logo-img { height: 46px; width: auto; object-fit: contain; }
      .nav-links { display: flex; gap: 28px; color: var(--muted); font-size: 0.95rem; }
      .nav-links a:hover, .footer a:hover { color: var(--blue); }
      .nav-actions { display: flex; align-items: center; gap: 10px; }
      .nav-phone { display: inline-flex; align-items: center; gap: 8px; color: var(--muted); font-size: 0.9rem; }
      .desktop-only { display: flex; }
      .mobile-only { display: none; }

      .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        border: 0;
        border-radius: 999px;
        padding: 12px 18px;
        cursor: pointer;
        transition: transform 180ms ease, box-shadow 180ms ease, background 180ms ease;
        white-space: nowrap;
      }
      .btn:hover { transform: translateY(-1px); }
      .btn-primary {
        background: linear-gradient(135deg, var(--gold), #c99d4f);
        color: #1b1b1b;
        box-shadow: 0 14px 30px rgba(214,178,111,0.28);
        font-weight: 700;
      }
      .btn-secondary {
        background: rgba(255,255,255,0.72);
        color: var(--blue);
        border: 1px solid rgba(31,45,107,0.12);
      }
      .btn-secondary.dark {
        background: rgba(255,255,255,0.08);
        color: #fff;
        border-color: rgba(255,255,255,0.14);
      }
      .full-width { width: 100%; }

      .mobile-panel {
        pointer-events: auto;
        width: min(1200px, calc(100vw - 24px));
        margin: 10px auto 0;
        padding: 14px;
        border-radius: 18px;
        background: rgba(255,248,235,0.98);
        border: 1px solid rgba(214,178,111,0.18);
        box-shadow: 0 16px 40px rgba(31,45,107,0.08);
        backdrop-filter: blur(16px);
        display: grid;
        gap: 12px;
      }
      .mobile-panel a { padding: 8px 2px; color: var(--muted); }

      .hero {
        min-height: 100vh;
        display: grid;
        grid-template-columns: 1.05fr 0.95fr;
        align-items: center;
        gap: 28px;
        padding: 140px 0 72px;
      }
      .hero-copy { padding-right: 8px; }
      .eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        color: var(--blue);
        font-family: Outfit, Inter, sans-serif;
        font-size: 0.82rem;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        margin-bottom: 18px;
      }
      .eyebrow.small { margin-bottom: 12px; }
      .hero-title {
        margin: 0;
        font-family: "Playfair Display", Georgia, serif;
        font-size: clamp(3rem, 7vw, 6.6rem);
        line-height: 0.96;
        letter-spacing: -0.03em;
        max-width: 8.5ch;
      }
      .hero-title span { color: var(--blue); }
      .hero-copy-text {
        max-width: 62ch;
        margin: 22px 0 0;
        color: var(--muted);
        font-size: 1.08rem;
        line-height: 1.8;
      }
      .hero-actions { display: flex; gap: 12px; margin-top: 28px; flex-wrap: wrap; }
      .hero-proof {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
        margin-top: 28px;
      }
      .hero-proof div, .trust-pill, .case-badge {
        border: 1px solid rgba(0,0,0,0.08);
        background: rgba(255,255,255,0.66);
        backdrop-filter: blur(12px);
      }
      .hero-proof div {
        border-radius: 18px;
        padding: 14px 16px;
      }
      .hero-proof strong, .feature-card h3, .premium-card h3, .industry-card h3, .case-card h3, .timeline-item h3, .founder-copy h3 {
        font-family: "Playfair Display", Georgia, serif;
        letter-spacing: -0.02em;
      }
      .hero-proof strong { display: block; margin-bottom: 4px; }
      .hero-proof span { color: var(--muted); font-size: 0.92rem; }

      .hero-visual {
        position: relative;
        min-height: 640px;
        border-radius: 32px;
        overflow: hidden;
        box-shadow: var(--shadow);
        border: 1px solid rgba(0,0,0,0.06);
        background: radial-gradient(circle at 30% 18%, rgba(214,178,111,0.22), transparent 38%),
                    radial-gradient(circle at 75% 25%, rgba(31,45,107,0.14), transparent 30%),
                    linear-gradient(180deg, rgba(255,255,255,0.78), rgba(247,243,235,0.9));
        transform-style: preserve-3d;
      }
      .hero-visual canvas { position: absolute !important; inset: 0; }
      .visual-overlay {
        position: absolute;
        inset: 0;
        pointer-events: none;
      }
      .glass-card {
        position: absolute;
        width: 220px;
        padding: 16px 18px;
        border-radius: 20px;
        background: rgba(255,255,255,0.42);
        border: 1px solid rgba(255,255,255,0.45);
        backdrop-filter: blur(16px);
        box-shadow: 0 18px 40px rgba(31,45,107,0.12);
      }
      .glass-card span { display: block; color: var(--muted); font-size: 0.82rem; margin-bottom: 8px; }
      .glass-card strong { display: block; font-family: "Playfair Display", Georgia, serif; font-size: 1.2rem; }
      .card-a { left: 26px; top: 34px; }
      .card-b { right: 26px; top: 160px; }
      .card-c { left: 46px; bottom: 34px; }

      .block-light { padding-top: 22px; }
      .block-ivory { padding-top: 22px; }
      .section { padding: 96px 0 0; }
      .section-heading {
        max-width: 760px;
        margin-bottom: 28px;
      }
      .section-heading h2, .cta-inner h2 {
        margin: 0;
        font-family: "Playfair Display", Georgia, serif;
        font-size: clamp(2.1rem, 4vw, 3.8rem);
        line-height: 1.06;
        letter-spacing: -0.03em;
      }
      .section-heading p, .cta-inner p { color: var(--muted); line-height: 1.8; margin: 14px 0 0; max-width: 70ch; }

      .card-grid, .industry-grid, .feature-grid, .timeline, .case-grid {
        display: grid;
        gap: 18px;
      }
      .card-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
      .premium-card, .industry-card, .feature-card, .timeline-item, .case-card, .founder-panel {
        border-radius: 24px;
        border: 1px solid var(--border);
        background: var(--card);
        backdrop-filter: blur(14px);
        box-shadow: 0 16px 40px rgba(31,45,107,0.06);
      }
      .premium-card {
        padding: 24px;
        min-height: 220px;
        position: relative;
        overflow: hidden;
      }
      .premium-card::after {
        content: "";
        position: absolute; inset: auto -10% -30% auto;
        width: 160px; height: 160px;
        background: radial-gradient(circle, rgba(214,178,111,0.12), transparent 65%);
      }
      .card-topline {
        width: 48px; height: 3px; border-radius: 999px; background: linear-gradient(90deg, var(--gold), var(--blue)); margin-bottom: 18px;
      }
      .premium-card p, .industry-card p, .feature-card p, .timeline-item p, .case-card p, .founder-copy p {
        color: var(--muted); line-height: 1.75;
        margin: 8px 0 0;
      }
      .tag-row { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 18px; }
      .tag-row span, .case-badge {
        font-size: 0.8rem;
        color: var(--blue);
        padding: 7px 10px;
        border-radius: 999px;
      }

      .industry-grid { grid-template-columns: repeat(4, minmax(0, 1fr)); }
      .industry-card {
        padding: 22px;
        min-height: 180px;
      }
      .industry-icon {
        width: 36px; height: 36px; border-radius: 12px;
        display: grid; place-items: center;
        background: rgba(214,178,111,0.14);
        color: var(--blue);
        margin-bottom: 14px;
      }

      .why-wrap { display: grid; grid-template-columns: 0.9fr 1.1fr; gap: 18px; }
      .trust-panel {
        display: grid;
        align-content: start;
        gap: 12px;
      }
      .trust-pill {
        border-radius: 18px;
        padding: 14px 16px;
        display: flex;
        align-items: center;
        gap: 10px;
        color: var(--blue);
      }
      .feature-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .feature-card { padding: 22px; min-height: 150px; }

      .timeline { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .timeline-item {
        padding: 20px;
        display: grid;
        grid-template-columns: auto 1fr;
        gap: 16px;
        align-items: start;
        opacity: 0.6;
        transform: translateY(16px);
      }
      .timeline-index {
        width: 44px; height: 44px; border-radius: 50%;
        display: grid; place-items: center;
        background: linear-gradient(135deg, rgba(214,178,111,0.2), rgba(31,45,107,0.1));
        color: var(--blue);
        font-weight: 700;
      }

      .case-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
      .case-card {
        padding: 20px;
        min-height: 280px;
        overflow: hidden;
        position: relative;
      }
      .case-visual {
        height: 120px;
        border-radius: 18px;
        margin-bottom: 16px;
        background: linear-gradient(135deg, rgba(31,45,107,0.08), rgba(214,178,111,0.12));
        position: relative;
        overflow: hidden;
      }
      .case-orb {
        position: absolute; left: 18px; top: 18px;
        width: 58px; height: 58px; border-radius: 50%;
        background: radial-gradient(circle at 30% 30%, rgba(255,255,255,0.9), rgba(214,178,111,0.45));
        box-shadow: 0 0 40px rgba(214,178,111,0.25);
      }
      .case-line {
        position: absolute; right: -18px; bottom: 18px;
        width: 65%; height: 2px;
        background: linear-gradient(90deg, transparent, rgba(31,45,107,0.4), transparent);
        transform: rotate(-14deg);
      }
      .case-badge {
        position: absolute; top: 16px; right: 16px;
        background: rgba(255,255,255,0.7);
        border: 1px solid rgba(0,0,0,0.08);
      }

      .founder-panel {
        display: grid;
        grid-template-columns: 240px 1fr;
        gap: 22px;
        padding: 26px;
      }
      .founder-portrait {
        min-height: 260px;
        border-radius: 24px;
        background: radial-gradient(circle at 35% 25%, rgba(214,178,111,0.22), transparent 40%), linear-gradient(180deg, rgba(31,45,107,0.08), rgba(255,255,255,0.6));
        display: grid;
        place-items: center;
        position: relative;
        overflow: hidden;
      }
      .portrait-ring {
        position: absolute;
        width: 180px; height: 180px; border-radius: 50%;
        border: 1px solid rgba(31,45,107,0.14);
      }
      .portrait-initials {
        width: 126px; height: 126px; border-radius: 50%;
        background: rgba(255,255,255,0.72);
        display: grid; place-items: center;
        font-family: "Playfair Display", Georgia, serif;
        font-size: 2.2rem;
        color: var(--blue);
        box-shadow: 0 14px 30px rgba(31,45,107,0.08);
      }
      .founder-copy h3 { font-size: 2rem; margin: 0; }
      .founder-notes {
        display: flex; flex-wrap: wrap; gap: 10px; margin-top: 18px;
      }
      .founder-notes span {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 10px 12px; border-radius: 999px;
        background: rgba(255,255,255,0.66); border: 1px solid rgba(0,0,0,0.08);
        color: var(--blue);
      }

      .cta-section {
        padding: 92px 0 0;
      }
      .cta-inner {
        border-radius: 34px;
        padding: clamp(28px, 5vw, 52px);
        background: radial-gradient(circle at top left, rgba(214,178,111,0.16), transparent 35%), linear-gradient(135deg, #20306e, #10193d);
        color: #fff;
        box-shadow: 0 30px 80px rgba(16,25,61,0.24);
      }
      .cta-eyebrow {
        display: inline-flex; font-family: Outfit, Inter, sans-serif; letter-spacing: 0.12em; text-transform: uppercase; font-size: 0.78rem; color: rgba(255,255,255,0.76);
        margin-bottom: 14px;
      }
      .cta-actions { display: flex; gap: 12px; margin-top: 24px; flex-wrap: wrap; }

      .footer {
        margin-top: 24px;
        padding: 36px 0 28px;
        color: rgba(255,255,255,0.84);
      }
      .footer {
        width: 100%;
        background: linear-gradient(180deg, #20243d, #16181f);
      }
      .footer-top, .footer-bottom {
        width: min(1200px, calc(100vw - 32px));
        margin: 0 auto;
      }
      .footer-top {
        display: grid;
        grid-template-columns: 1.4fr 1fr 1fr 1fr;
        gap: 24px;
        padding: 18px 0 26px;
      }
      .footer h3 {
        font-family: "Playfair Display", Georgia, serif;
        margin: 0 0 12px;
        color: #fff;
      }
      .footer a, .footer span { display: block; margin: 8px 0; color: rgba(255,255,255,0.78); }
      .footer-logo-wrap { display: inline-flex; padding: 8px 0 16px; }
      .footer-logo { height: 46px; width: auto; }
      .footer-btn {
        margin-top: 10px;
        border: 0;
        border-radius: 999px;
        padding: 10px 14px;
        background: linear-gradient(135deg, var(--gold), #c99d4f);
        color: #1b1b1b;
        font-weight: 700;
      }
      .footer-bottom {
        border-top: 1px solid rgba(255,255,255,0.1);
        padding-top: 16px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        gap: 12px;
        color: rgba(255,255,255,0.58);
        font-size: 0.92rem;
      }

      .modal-backdrop {
        position: fixed;
        inset: 0;
        z-index: 80;
        display: grid;
        place-items: center;
        background: rgba(14, 16, 24, 0.48);
        backdrop-filter: blur(10px);
        padding: 18px;
      }
      .modal-shell {
        position: relative;
        width: min(760px, 100%);
        border-radius: 28px;
        padding: 26px;
        background: linear-gradient(180deg, rgba(26,30,44,0.96), rgba(12,14,22,0.96));
        border: 1px solid rgba(255,255,255,0.08);
        box-shadow: 0 30px 90px rgba(0,0,0,0.35);
        color: #fff;
      }
      .modal-close {
        position: absolute;
        top: 16px; right: 16px;
        width: 38px; height: 38px; border-radius: 50%;
        border: 0;
        background: rgba(255,255,255,0.08);
        color: #fff;
        display: grid; place-items: center;
      }
      .modal-header h2 {
        margin: 0;
        font-family: "Playfair Display", Georgia, serif;
        font-size: clamp(1.9rem, 3vw, 3rem);
        line-height: 1.05;
      }
      .modal-header p { color: rgba(255,255,255,0.72); line-height: 1.7; max-width: 60ch; }
      .modal-eyebrow {
        display: inline-flex; margin-bottom: 12px; color: rgba(255,255,255,0.72); letter-spacing: 0.12em; text-transform: uppercase; font-size: 0.75rem;
      }
      .consultation-form { margin-top: 22px; }
      .form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; }
      .field { display: grid; gap: 8px; }
      .field-full { margin-top: 14px; }
      .field span { color: rgba(255,255,255,0.8); font-size: 0.92rem; }
      .field input, .field select, .field textarea {
        width: 100%;
        border-radius: 16px;
        border: 1px solid rgba(255,255,255,0.1);
        background: rgba(255,255,255,0.06);
        color: #fff;
        padding: 14px 15px;
        outline: none;
      }
      .field textarea { resize: vertical; min-height: 128px; }
      .field input::placeholder, .field textarea::placeholder { color: rgba(255,255,255,0.42); }
      .form-footer {
        display: flex; justify-content: space-between; align-items: center; gap: 14px;
        margin-top: 18px;
      }
      .form-note {
        color: rgba(255,255,255,0.72);
        display: inline-flex; align-items: center; gap: 8px;
      }
      .submission-state {
        margin-top: 22px;
        padding: 24px;
        border-radius: 22px;
        background: rgba(255,255,255,0.06);
        display: grid; gap: 10px; place-items: start;
      }

      @media (max-width: 1100px) {
        .hero, .why-wrap, .founder-panel, .footer-top { grid-template-columns: 1fr; }
        .hero { padding-top: 128px; }
        .hero-visual { min-height: 520px; }
        .card-grid, .industry-grid, .case-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .timeline { grid-template-columns: 1fr; }
      }
      @media (max-width: 780px) {
        .desktop-only { display: none; }
        .mobile-only { display: inline-flex; }
        .nav-bar { padding: 10px 12px; }
        .logo-img, .footer-logo { height: 36px; }
        .hero { grid-template-columns: 1fr; min-height: auto; padding-top: 116px; }
        .hero-title { max-width: 10ch; }
        .hero-proof, .card-grid, .industry-grid, .feature-grid, .case-grid, .form-grid { grid-template-columns: 1fr; }
        .hero-visual { min-height: 420px; }
        .glass-card { width: 180px; }
        .card-a { left: 16px; top: 16px; }
        .card-b { right: 16px; top: 120px; }
        .card-c { left: 16px; bottom: 16px; }
        .form-footer, .cta-actions, .nav-actions { flex-direction: column; align-items: stretch; }
        .founder-panel { padding: 18px; }
        .footer-bottom { flex-direction: column; }
      }
    `}</style>
  );
}

export default App;
