KALTERA AI Premium Website

Files:
- src/App.jsx
- src/main.jsx
- index.html
- package.json
- vite.config.js

Place the original logo file at:
- public/kaltera-logo-dark.png

Run:
npm install
npm run dev
